package com.example.demoFinalmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFinalmavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFinalmavenApplication.class, args);
	}

}
